"""从实际C1九工况校验测量链，归档全部成功/失败原始数据。"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

import numpy as np
import pandas as pd

from common.force_sensor import ForceSensor
from experiments.c1_wipe import load_config, motion_metrics

ROOT = Path.cwd()
AUDIT = ROOT.parent.parent/'audit'
SOURCE = ROOT/'results/CS/run_001'
OUT = ROOT/'docs/evidence/c1-sensor-study-2026-10-25'
OUT.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

table = pd.read_csv(SOURCE/'comparison.csv')
base = {**load_config(), 'pi_algorithm': 'fixed'}
checks, scenes = [], set()
for row in table.to_dict('records'):
    folder = SOURCE/row['数据目录']
    config, summary = read(folder/'config.json'), read(folder/'summary.json')
    changed = {k for k in config.keys() | base.keys() if config.get(k) != base.get(k)}
    assert all(k.startswith('sensor_') for k in changed), changed
    frame, command = pd.read_csv(folder/'contact_force.csv'), pd.read_csv(folder/'control.csv')
    physical = frame.set_index('time_s').loc[command.time_s, 'normal_force_n'].to_numpy()
    np.testing.assert_allclose(physical, command.sensor_true_force_n, atol=1e-12, rtol=0)
    np.testing.assert_allclose(command.measured_force_n, command.sensor_filtered_force_n, atol=1e-12, rtol=0)
    sensor = ForceSensor(config, config['control_dt_s'])
    reconstructed, sources = [], []
    for force, time in zip(physical, command.time_s):
        value, detail = sensor.step(force, time)
        reconstructed.append(value); sources.append(detail['sensor_source_time_s'])
    np.testing.assert_allclose(reconstructed, command.measured_force_n, atol=1e-12, rtol=0)
    np.testing.assert_allclose(sources, command.sensor_source_time_s, atol=1e-12, rtol=0)
    assert command.pi_kp_m_per_n.eq(base['pi_kp_m_per_n']).all()
    assert command.pi_ki_m_per_ns.eq(base['pi_ki_m_per_ns']).all()
    assert command[[f'ctrl_{i}' for i in range(7)]].diff().abs().max().max() <= base['max_joint_reference_speed_rad_s']*base['control_dt_s']+1e-12
    result = motion_metrics(frame, config)
    assert result['连续接触与实际往返验收'] == row['任务验收通过']
    assert abs(result['运动法向力RMSE_N']-row['运动法向力RMSE_N']) < 1e-12
    scenes.add(summary['scene_sha256'])
    motion_cmd = command[(command.time_s >= 10) & (command.time_s < 26)]
    checks.append({'case': row['工况'], 'measurement_reconstruction_max_error_n': float(np.max(np.abs(command.measured_force_n-np.array(reconstructed)))),
                   'sensor_parameters_only_changed': sorted(changed),
                   'motion_mean_true_force_n': float(motion_cmd.sensor_true_force_n.mean()),
                   'motion_mean_measured_force_n': float(motion_cmd.measured_force_n.mean()),
                   'observed_max_queue_delay_s': float(command.sensor_actual_delay_s.max()),
                   'passed': bool(summary['passed'])})
assert len(scenes) == 1
pd.testing.assert_frame_equal(pd.read_csv(SOURCE/'c0/run_001/contact_force.csv'),
                              pd.read_csv(ROOT/'results/C1_Wipe/run_002/contact_force.csv'))
for name in ['comparison.csv', 'study_config.json', 'study_summary.json', 'c1_sensor_study.png']:
    shutil.copy2(SOURCE/name, OUT/name)

# 三种子与九工况都按实际运行保存，未来出现FAIL也不筛掉。
files = [SOURCE/name for name in ['comparison.csv', 'study_config.json', 'study_summary.json', 'c1_sensor_study.png']]
keep = {'config.json', 'summary.json', 'c1_metrics.json', 'contact_scene.xml',
        'contact_force.csv', 'control.csv', 'raw_contacts.csv', 'joint_state.csv',
        'run.log', 'c1_curves.png', 'model_report.json', 'scene_report.json'}
for row in table.to_dict('records'):
    files.extend(sorted(p for p in (SOURCE/row['数据目录']).iterdir() if p.name in keep))
chunks, chunk, size = [], [], 0
for file in files:
    if chunk and size + file.stat().st_size > 80_000_000:
        chunks.append(chunk); chunk, size = [], 0
    chunk.append(file); size += file.stat().st_size
if chunk:
    chunks.append(chunk)
archives, members = {}, {}
for index, chunk in enumerate(chunks, 1):
    archive = OUT/f'raw_data_{index:02d}.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for file in chunk:
            name = file.relative_to(SOURCE).as_posix()
            z.write(file, name)
            members[name] = {'archive': archive.name, 'sha256': sha(file), 'bytes': file.stat().st_size}
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    archives[archive.name] = {'sha256': sha(archive), 'bytes': archive.stat().st_size, 'entries': len(chunk)}
logs = ['panda_c1_sensor_study_2026-10-25.log', 'panda_c1_sensor_full_tests_2026-10-25.log']
with zipfile.ZipFile(OUT/'verification_logs.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name in logs:
        z.write(AUDIT/name, name)
    z.write(Path(__file__).resolve(), 'package_c1_sensor_evidence.py')
archive = OUT/'verification_logs.zip'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    archives[archive.name] = {'sha256': sha(archive), 'bytes': archive.stat().st_size, 'entries': len(z.infolist())}
log = (AUDIT/logs[1]).read_text(encoding='utf-8-sig')
assert '77 passed' in log
save(OUT/'manifest.json', {'archives': archives, 'raw_members': members})
save(OUT/'verification.json', {
    'date': '2026-10-25', 'parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'source_sha256': {p.as_posix(): sha(ROOT/p) for p in map(Path, ['experiments/c1_sensor_study.py', 'tests/test_c1_sensor_study.py'])},
    'checks': checks, 'identical_scene_sha256': list(scenes)[0], 'zero_trace_exactly_matches_previous_8s_baseline': True,
    'test_command': 'python -m pytest tests -q --basetemp=t_all',
    'regression_result': next(line for line in log.splitlines() if line.startswith('77 passed')),
    'simulation_command': 'python -m experiments.c1_sensor_study',
    'versions': read(SOURCE/'c0/run_001/summary.json')['versions'],
    'python': read(SOURCE/'c0/run_001/summary.json')['python'],
    'limits': ['九组同为固定PI、单一接触模型和5N目标；不是模糊PI对照。',
               '原C1任务无运动段力RMSE门槛，9/9仅表示原任务通过。',
               '500ms延迟本次通过不代表安全上限或全工况稳定。',
               '本次九工况没有新增实际FAIL；历史原3秒和24次失败Debug材料保留。',
               '测试和实验采用已有Python环境，未验证真机或交互窗口。']})
print(json.dumps({'archives': archives, 'total_bytes': sum(v['bytes'] for v in archives.values()),
                  'measurement_max_error_n': max(c['measurement_reconstruction_max_error_n'] for c in checks),
                  'bias_case': next(c for c in checks if c['case']=='bias')}, ensure_ascii=False))
