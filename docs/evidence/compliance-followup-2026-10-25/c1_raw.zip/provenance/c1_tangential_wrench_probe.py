"""用外力矩/Kp补偿切向负载，检查是否为位置伺服法向/切向耦合；仅诊断。"""
from pathlib import Path
import numpy as np
import mujoco

import experiments.c1_wipe as wipe
import experiments.m0_03_contact_force as loop
from common.kinematics import solve_pose

state = {"time": 0., "force": np.zeros(3)}
original = wipe.WipeReference.__call__
def reference(self, t, initial, normal, config, measured):
    state["time"] = t
    state["force"] = np.array([measured[f"tool_force_{a}_n"] for a in "xyz"])
    return original(self, t, initial, normal, config, measured)
wipe.WipeReference.__call__ = reference

def pose(model, data, site, arm, target, rotation, config):
    q = solve_pose(model, data, site, arm, target, rotation, config)
    v = wipe.wipe_displacement(state["time"], config)[1]
    blend = min(1., abs(v) / .001)
    normal = np.asarray(config["normal_world"])
    tangential = state["force"] - normal * (normal @ state["force"])
    jp, jr = np.zeros((3, model.nv)), np.zeros((3, model.nv))
    mujoco.mj_jacSite(model, data, jp, jr, site)
    ids = [next(a for a in range(model.nu) if model.actuator_trnid[a, 0] == j) for j in arm]
    return q - blend * (jp[:, model.jnt_dofadr[arm]].T @ tangential) / model.actuator_gainprm[ids, 0]
loop.solve_pose = pose
wipe.run(wipe.load_config(), Path("results/Cwrench"))
