"""基于法向位置变化率的附加阻尼；不改变环境、轨迹、目标与限幅。"""
import json
from pathlib import Path
import numpy as np

import experiments.c1_wipe as wipe
from controllers.force_pi import ForcePI

state = {"last_z": None, "velocity": 0., "gain": 0.}
original = wipe.WipeReference.__call__
def reference(self, t, initial, normal, config, measured):
    z = sum(measured[f"tool_{a}_m"] * normal[i] for i, a in enumerate("xyz"))
    state["velocity"] = 0. if state["last_z"] is None else (z - state["last_z"]) / config["control_dt_s"]
    state["last_z"] = z
    return original(self, t, initial, normal, config, measured)
wipe.WipeReference.__call__ = reference
def step(self, target, measured, dt):
    error = target - measured
    proposed = float(np.clip(self.integral + self.ki * error * dt, -self.integral_limit, self.integral_limit))
    ff = state["gain"] * state["velocity"]
    lower, upper = max(-self.offset_limit, self.offset-self.speed*dt), min(self.offset_limit, self.offset+self.speed*dt)
    raw = self.kp*error + proposed + ff
    applied = float(np.clip(raw, lower, upper))
    blocked = (raw-applied)*error > 0
    if blocked:
        raw = self.kp*error + self.integral + ff
        applied = float(np.clip(raw, lower, upper))
    else:
        self.integral = proposed
    self.offset = applied
    return applied, {"force_error_n": error, "pi_p_m": self.kp*error, "pi_i_m": self.integral,
                     "pi_offset_m": applied, "pi_unsaturated_m": raw, "pi_integral_blocked": bool(blocked),
                     "pi_output_limited": bool(abs(raw-applied)>1e-15), "normal_damping_offset_m": ff}
ForcePI.step = step
root = Path("results/Cdamp")
rows = []
for name, gain in [("d05", .05), ("d20", .2)]:
    state.update(last_z=None, velocity=0., gain=gain)
    try:
        output = wipe.run(wipe.load_config(), root/name)
    except ValueError as exc:
        output = root/name/"run_001"
        print(f"工况 {name} 保留失败：{exc}", flush=True)
    path = output/"c1_metrics.json"
    rows.append({"case": name, "gain_s": gain, "metrics": json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"error": "提前失败"}})
(root/"comparison.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
