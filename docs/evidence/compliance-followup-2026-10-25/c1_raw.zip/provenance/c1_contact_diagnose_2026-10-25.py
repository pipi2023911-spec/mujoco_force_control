"""检查接触求解与积分反馈；审计试验，不直接修改默认环境。"""
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import mujoco
from common.contact_scene import build_scene, load_model, reset_home
import experiments.m0_03_contact_force as loop
from experiments.c1_wipe import load_config, run

root = Path("results/Ccontact")
cases = [("integral_dominant", {"pi_kp_m_per_n": 2e-6, "pi_ki_m_per_ns": 1/1500,
                                 "pi_offset_speed_m_s": .004}, {}),
         ("elliptic", {}, {"cone": "elliptic"}),
         ("implicit", {}, {"integrator": "implicit"})]
rows = []
for name, change, options in cases:
    def scene(config, output_xml):
        model, data, report = build_scene(config, output_xml)
        if options:
            tree = ET.parse(output_xml)
            tree.getroot().find("option").attrib.update(options)
            tree.write(output_xml, encoding="unicode")
            model = load_model(output_xml)
            data = reset_home(model, config["home_key"])
        return model, data, report
    loop.build_scene = scene
    try:
        output = run({**load_config(), **change}, root / name)
    except ValueError as exc:
        output = root / name / "run_001"
        print(f"诊断 {name} 保留失败：{exc}", flush=True)
    path = output / "c1_metrics.json"
    rows.append({"case": name, "change": change, "options": options,
                 "metrics": json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"error": "物理循环提前失败"}})
(root / "comparison.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
