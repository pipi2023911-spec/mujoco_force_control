"""C1 单因素诊断；保留原任务阈值、行程和时序，不改源码默认参数。"""
import json
from pathlib import Path

from experiments.c1_wipe import load_config, run

root = Path("results/Cdiag")
cases = [("fuzzy", {"pi_algorithm": "fuzzy"}),
         ("lpf20", {"sensor_lpf_cutoff_hz": 20.}),
         ("kp_half", {"pi_kp_m_per_n": 1e-5}),
         ("kp_small", {"pi_kp_m_per_n": 2e-6})]
rows = []
for name, change in cases:
    try:
        output = run({**load_config(), **change}, root / name)
    except ValueError as exc:
        output = root / name / "run_001"
        print(f"诊断工况 {name} 保留失败：{exc}", flush=True)
    metric = output / "c1_metrics.json"
    rows.append({"case": name, "change": change,
                 "metrics": json.loads(metric.read_text(encoding="utf-8")) if metric.exists() else {"error": "物理循环提前失败"}})
(root / "comparison.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
