"""隔离位置执行器阻尼引起的运动滞后；仅对解析切向速度做前馈。"""
from pathlib import Path
import numpy as np
import mujoco

import experiments.c1_wipe as wipe
import experiments.m0_03_contact_force as loop
from common.kinematics import solve_pose

clock = {"time": 0.}
original = wipe.WipeReference.__call__
def reference(self, t, *args):
    clock["time"] = t
    return original(self, t, *args)
wipe.WipeReference.__call__ = reference

def pose(model, data, site, arm, target, rotation, config):
    q = solve_pose(model, data, site, arm, target, rotation, config)
    jp, jr = np.zeros((3, model.nv)), np.zeros((3, model.nv))
    mujoco.mj_jacSite(model, data, jp, jr, site)
    va = model.jnt_dofadr[arm]
    w = config["ik_orientation_weight_m"]
    jac = np.vstack([jp[:, va], w * jr[:, va]])
    twist = np.array([wipe.wipe_displacement(clock["time"], config)[1], 0, 0, 0, 0, 0])
    qvel = jac.T @ np.linalg.solve(jac @ jac.T + config["ik_damping"]**2 * np.eye(6), twist)
    ids = [next(a for a in range(model.nu) if model.actuator_trnid[a, 0] == j) for j in arm]
    return q + (-model.actuator_biasprm[ids, 2] / model.actuator_gainprm[ids, 0]) * qvel
loop.solve_pose = pose
wipe.run(wipe.load_config(), Path("results/Cff"))
