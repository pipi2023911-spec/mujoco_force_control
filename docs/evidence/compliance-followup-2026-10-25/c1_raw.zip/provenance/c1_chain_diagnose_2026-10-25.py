"""区分修正速率、物理步长与摩擦的影响；不把改变环境的结果当作原场景修复。"""
import json
from pathlib import Path

from experiments.c1_wipe import load_config, run

root = Path("results/Cchain")
cases = [("rate2", {"pi_offset_speed_m_s": .002}),
         ("rate4", {"pi_offset_speed_m_s": .004}),
         ("dt_half", {"physics_dt_s": .0005}),
         ("no_friction_diagnostic_only", {"contact_friction": [0., .005, .0001]})]
rows = []
for name, change in cases:
    try:
        output = run({**load_config(), **change}, root / name)
    except ValueError as exc:
        output = root / name / "run_001"
        print(f"诊断 {name} 保留失败：{exc}", flush=True)
    path = output / "c1_metrics.json"
    rows.append({"case": name, "change": change, "metrics": json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"error": "物理循环提前失败"}})
(root / "comparison.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
