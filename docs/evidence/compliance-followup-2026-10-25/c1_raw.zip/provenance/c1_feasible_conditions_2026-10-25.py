"""检查任务可行工况；改变环境/速度的结果必须与原场景分开报告。"""
import json
from pathlib import Path
from experiments.c1_wipe import load_config, run

root = Path("results/Cconditions")
cases = [("solref04", {"contact_solref": [.04, 1.]}),
         ("impedance05", {"contact_solimp": [.5, .95, .001]}),
         ("friction04", {"contact_friction": [.4, .005, .0001]}),
         ("slower6s", {"wipe_leg_duration_s": 6., "duration_s": 23.})]
rows = []
for name, change in cases:
    try:
        output = run({**load_config(), **change}, root / name)
    except ValueError as exc:
        output = root / name / "run_001"
        print(f"工况 {name} 保留失败：{exc}", flush=True)
    path = output / "c1_metrics.json"
    rows.append({"case": name, "change": change,
                 "metrics": json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"error": "物理循环提前失败"}})
(root / "comparison.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
