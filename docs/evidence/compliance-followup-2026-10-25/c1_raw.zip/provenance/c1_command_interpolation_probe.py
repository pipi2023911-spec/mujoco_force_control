"""仅把5ms执行器目标阶梯改成物理步线性斜坡，检验离散激励。"""
from pathlib import Path
import numpy as np
import mujoco
from experiments.c1_wipe import load_config, run

c = load_config()
substeps = round(c["control_dt_s"] / c["physics_dt_s"])
state = {"index": 0, "last": None}
original = mujoco.mj_step
def step(model, data):
    k = state["index"] % substeps
    if k == 0:
        state["start"] = data.ctrl.copy() if state["last"] is None else state["last"].copy()
        state["end"] = data.ctrl.copy()
    data.ctrl[:] = state["start"] + ((k + 1) / substeps) * (state["end"] - state["start"])
    original(model, data)
    state["last"] = data.ctrl.copy()
    state["index"] += 1
mujoco.mj_step = step
run(c, Path("results/Cinterp"))
