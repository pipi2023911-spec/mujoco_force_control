"""与锁定旧提交的真实导纳实现对照，不只比较两个新配置。"""
import json
import subprocess
import numpy as np

from controllers.admittance import Admittance
from experiments.m2_admittance import load_config

old_source = subprocess.check_output(["git", "show", "98eaba5:controllers/admittance.py"], text=True, encoding="utf-8")
namespace = {}
exec(compile(old_source, "old_admittance_98eaba5.py", "exec"), namespace)
config = load_config()
old, new = namespace["Admittance"](config), Admittance(config)
rng = np.random.default_rng(42)
for force in rng.uniform(-20., 20., 10000):
    x0, s0 = old.step(force, config["control_dt_s"])
    x1, s1 = new.step(force, config["control_dt_s"])
    assert x0 == x1
    assert all(s0[key] == s1[key] for key in s0)
print(json.dumps({"legacy_commit": "98eaba5", "steps": 10000,
                  "default_target_zero_original_fields": "逐值一致"}, ensure_ascii=False))
