"""局部逆动力学扫描：定向滑动速度下，接触力对真实压入量的关系。"""
from pathlib import Path
import json
import mujoco
import numpy as np
import pandas as pd

from common.contact_scene import load_model
from common.contact_feedback import contact_force
from common.kinematics import solve_pose
from experiments.c1_wipe import load_config

c = load_config()
root = Path("t_all/test_real_short_round_trip_and0/run_001")
m = load_model(root/"contact_scene.xml")
q = pd.read_csv(root/"joint_state.csv")
sample = q.iloc[np.argmin(abs(q.time_s.to_numpy()-11.))]
site, tool, plate = [m.site("tool_tip").id, m.geom("tool_sphere").id, m.geom("contact_plane").id]
arm = np.array([m.joint(n).id for n in c["arm_joints"]])
d0 = mujoco.MjData(m)
d0.qpos[:] = sample[[f"qpos_{i}" for i in range(m.nq)]]
mujoco.mj_forward(m, d0)
start = d0.site_xpos[site].copy()
rotation = d0.site_xmat[site].reshape(3,3).copy()
z_touch = d0.geom_xpos[plate,2]+m.geom_size[plate,2]+c["tool_radius_m"]
rows = []
for speed in [0., .002, .004, .00625, -.00625]:
    for depth in [1e-8, 1e-6, 5e-6, 2e-5, 5e-5, 1e-4, 2e-4]:
        d = mujoco.MjData(m)
        d.qpos[:] = d0.qpos
        p = start.copy(); p[2] = z_touch-depth
        fine = {**c, "ik_position_tolerance_m": 1e-11, "ik_orientation_tolerance_rad": 1e-10}
        solve_pose(m, d, site, arm, p, rotation, fine)
        mujoco.mj_forward(m, d)
        jp,jr=np.zeros((3,m.nv)),np.zeros((3,m.nv))
        mujoco.mj_jacSite(m,d,jp,jr,site)
        jac=np.vstack([jp[:,:7],jr[:,:7]])
        d.qvel[:7]=np.linalg.pinv(jac)@np.array([speed,0,0,0,0,0])
        d.qacc[:]=0.
        mujoco.mj_inverse(m,d)
        f=contact_force(m,d,tool,plate,[0,0,1])
        rows.append({"speed_m_s":speed,"depth_m":depth,"force_n":f["normal_force_n"],
                     "tangential_force_n":float(f["force_world_n"][0]),"contacts":f["tool_contact_count"]})
out=Path("results/Cinverse");out.mkdir(parents=True,exist_ok=True)
pd.DataFrame(rows).to_csv(out/"force_depth.csv",index=False)
print(pd.DataFrame(rows).pivot(index="depth_m",columns="speed_m_s",values="force_n").to_string())
