"""同一接触参数/控制周期下对照数值积分方案，不修改力控器或验收。"""
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import experiments.m0_03_contact_force as loop
from common.contact_scene import build_scene, load_model, reset_home
from experiments.c1_wipe import load_config, run

root = Path("results/Cintegration")
rows = []
for name in ["RK4", "Euler"]:
    def scene(config, xml):
        _, _, report = build_scene(config, xml)
        tree = ET.parse(xml)
        tree.getroot().find("option").set("integrator", name)
        tree.write(xml, encoding="unicode")
        model = load_model(xml)
        return model, reset_home(model, config["home_key"]), report
    loop.build_scene = scene
    try:
        output = run(load_config(), root/name)
    except ValueError as exc:
        output = root/name/"run_001"
        print(f"积分对照 {name} 保留失败：{exc}", flush=True)
    file = output/"c1_metrics.json"
    metrics = json.loads(file.read_text(encoding="utf-8")) if file.exists() else json.loads((output/"summary.json").read_text(encoding="utf-8"))
    rows.append({"integrator": name, "metrics": metrics})
(root/"comparison.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
