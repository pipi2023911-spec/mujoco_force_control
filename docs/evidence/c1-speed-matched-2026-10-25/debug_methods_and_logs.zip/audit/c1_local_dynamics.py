"""从已记录的实际关节状态重建质量/Jacobian/静态柔顺矩阵，核对摩擦耦合。"""
from pathlib import Path
import json
import mujoco
import numpy as np
import pandas as pd
from common.contact_scene import load_model

root = Path("t_all/test_real_short_round_trip_and0/run_001")
model = load_model(root/"contact_scene.xml")
data = mujoco.MjData(model)
q = pd.read_csv(root/"joint_state.csv")
rows = []
for t in [10., 11., 11.003, 13., 14.5]:
    sample = q.iloc[np.argmin(abs(q.time_s.to_numpy()-t))]
    data.qpos[:] = sample[[f"qpos_{i}" for i in range(model.nq)]]
    data.qvel[:] = sample[[f"qvel_{i}" for i in range(model.nv)]]
    mujoco.mj_forward(model, data)
    mass = np.zeros((model.nv, model.nv))
    mujoco.mj_fullM(model, mass, data.qM)
    jp, jr = np.zeros((3, model.nv)), np.zeros((3, model.nv))
    mujoco.mj_jacSite(model, data, jp, jr, model.site("tool_tip").id)
    j = jp[:, :7]
    mobility = j @ np.linalg.solve(mass[:7, :7], j.T)
    compliance = (j / np.array([4500,4500,3500,3500,2000,2000,2000])) @ j.T
    rows.append({"time":t, "mobility":mobility.tolist(), "compliance_m_per_n":compliance.tolist(),
                 "mu_cross_to_normal_mass":float(.8*mobility[2,0]/mobility[2,2]),
                 "mu_cross_to_normal_stiffness":float(.8*compliance[2,0]/compliance[2,2]),
                 "normal_velocity_m_s":float((j @ data.qvel[:7])[2]),
                 "iterations":data.solver_niter.tolist()})
Path("../../audit/c1_local_dynamics.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
print(json.dumps(rows, indent=2))
