"""逆接触解回代正向动力学，核对法向力与边正则化，非控制器实测。"""
from pathlib import Path
import json
import mujoco
import numpy as np
import pandas as pd
from common.contact_scene import load_model
from common.contact_feedback import contact_force
from common.kinematics import solve_pose
from experiments.c1_wipe import load_config

c=load_config();root=Path("t_all/test_real_short_round_trip_and0/run_001")
m=load_model(root/"contact_scene.xml");d0=mujoco.MjData(m)
states=pd.read_csv(root/"joint_state.csv");row=states.iloc[np.argmin(abs(states.time_s.to_numpy()-11.))]
d0.qpos[:]=row[[f"qpos_{i}" for i in range(m.nq)]];mujoco.mj_forward(m,d0)
site=m.site("tool_tip").id;tool=m.geom("tool_sphere").id;plate=m.geom("contact_plane").id
arm=np.array([m.joint(n).id for n in c["arm_joints"]]);va=m.jnt_dofadr[arm]
start=d0.site_xpos[site].copy();rotation=d0.site_xmat[site].reshape(3,3).copy()
touch=d0.geom_xpos[plate,2]+m.geom_size[plate,2]+c["tool_radius_m"]
records=[]
for speed in [0.,.002,.0025,.003125,.00625]:
    for depth in [1e-8,2e-5]:
        d=mujoco.MjData(m);d.qpos[:]=d0.qpos
        target=start.copy();target[2]=touch-depth
        solve_pose(m,d,site,arm,target,rotation,{**c,"ik_position_tolerance_m":1e-11,"ik_orientation_tolerance_rad":1e-10})
        mujoco.mj_forward(m,d)
        jp,jr=np.zeros((3,m.nv)),np.zeros((3,m.nv))
        mujoco.mj_jacSite(m,d,jp,jr,site);jac=np.vstack([jp[:,va],jr[:,va]])
        d.qvel[va]=np.linalg.pinv(jac)@np.array([speed,0,0,0,0,0])
        # qacc=0时Cartesian加速度很小；另记录其大小，避免把它称为严格零加速度TCP。
        mujoco.mj_forward(m,d)
        acc=np.zeros(6);mujoco.mj_objectAcceleration(m,d,mujoco.mjtObj.mjOBJ_SITE,site,acc,0)
        d.qacc[:]=0.;mujoco.mj_inverse(m,d)
        inverse_force=contact_force(m,d,tool,plate,[0,0,1])["normal_force_n"]
        desired_tau=d.qfrc_inverse.copy()
        # 手指状态也通过qfrc_applied补齐，确保整模型的正向/逆向回代，而非只验证7轴。
        d.ctrl[:]=0.;mujoco.mj_fwdActuation(m,d)
        d.qfrc_applied[:]=desired_tau-d.qfrc_actuator
        mujoco.mj_forward(m,d)
        forward_force=contact_force(m,d,tool,plate,[0,0,1])["normal_force_n"]
        contact=next(d.contact[i] for i in range(d.ncon) if set(d.contact[i].geom)=={tool,plate})
        address=int(contact.efc_address)
        record={"speed_m_s":speed,"depth_m":depth,"inverse_force_n":inverse_force,
                "forward_force_n":forward_force,"qacc_norm":float(np.linalg.norm(d.qacc)),
                "R_edges":d.efc_R[address:address+4].tolist(),
                "aref_edges":d.efc_aref[address:address+4].tolist(),
                "force_edges":d.efc_force[address:address+4].tolist()}
        assert abs(inverse_force-forward_force)<1e-7
        assert record["qacc_norm"]<1e-6
        records.append(record)
Path("results/Cinverse/forward_check.json").write_text(json.dumps(records,indent=2),encoding="utf-8")
print(json.dumps(records,indent=2))
