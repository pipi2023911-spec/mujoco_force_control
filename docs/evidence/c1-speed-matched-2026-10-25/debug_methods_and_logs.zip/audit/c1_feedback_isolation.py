"""区分滑动接触自身抬离与法向PI反馈激励，冻结是诊断而非修复。"""
import json
from pathlib import Path

import experiments.c1_wipe as wipe
from controllers.force_pi import ForcePI

clock = {"time": 0., "freeze": False}
reference_call = wipe.WipeReference.__call__
def reference(self, t, *args):
    clock["time"] = t
    return reference_call(self, t, *args)
wipe.WipeReference.__call__ = reference
original = ForcePI.step
def step(self, target, force, dt):
    if not clock["freeze"] or clock["time"] < 10:
        return original(self, target, force, dt)
    return self.offset, {"force_error_n": target-force, "pi_p_m": self.kp*(target-force),
                         "pi_i_m": self.integral, "pi_offset_m": self.offset,
                         "pi_unsaturated_m": self.offset, "pi_integral_blocked": False,
                         "pi_output_limited": False, "diagnostic_frozen": True}
ForcePI.step = step
rows = []
for name, config in [("frozen_at_motion", {}), ("lpf2", {"sensor_lpf_cutoff_hz": 2.}),
                     ("slow_integral", {"pi_ki_m_per_ns": .00003})]:
    clock.update(time=0., freeze=name == "frozen_at_motion")
    root = Path("results/Cisolate")/name
    try:
        output = wipe.run({**wipe.load_config(), **config}, root)
    except ValueError as exc:
        output = root/"run_001"
        print(f"隔离实验 {name} 未通过：{exc}", flush=True)
    path = output/"c1_metrics.json"
    rows.append({"case": name, "config": config,
                 "metrics": json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"error": "提前失败"}})
Path("results/Cisolate/comparison.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
